from endstone_ye111566_menu.ye111566_menu import Ye111566Menu

__all__ = ["Ye111566Menu"]